from PyQt5.QtWidgets import * 
import sys
from PyQt5.QtCore import  *
from PyQt5.QtGui import  *
from PyQt5.QtSql import *
from PyQt5.Qt import *
import time
from bircalc import BirthdayCalculator

class page_2(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        # 设置窗口的标题、位置和大小
        self.setWindowTitle('日期输入')
        #self.setGeometry(300, 300, 400, 100)

        # 创建三个标签和三个QSpinBox控件
        year_label = QLabel('Year:', self)
        self.year_spin = QSpinBox(self)
        self.year_spin.setRange(1900, 2100)
        self.year_spin.setValue(2023)

        month_label = QLabel('Month:', self)
        self.month_spin = QSpinBox(self)
        self.month_spin.setRange(1, 12)
        self.month_spin.setValue(3)

        day_label = QLabel('Day:', self)
        self.day_spin = QSpinBox(self)
        self.day_spin.setRange(1, 31)
        self.day_spin.setValue(6)

        self.btn = QPushButton('确认', self)
        self.btn.clicked.connect(self.show_text)

        self.label1 = QLabel(self)
        self.label1.setAlignment(Qt.AlignLeft)
        self.label2 = QLabel(self)
        self.label2.setAlignment(Qt.AlignLeft)
        self.label3 = QLabel(self)
        self.label3.setAlignment(Qt.AlignLeft)
        self.label4 = QLabel(self)
        self.label4.setAlignment(Qt.AlignLeft)

        vbox = QVBoxLayout()
        hbox = QHBoxLayout()
        hbox.addWidget(year_label)
        hbox.addWidget(self.year_spin)
        hbox.addWidget(month_label)
        hbox.addWidget(self.month_spin)
        hbox.addWidget(day_label)
        hbox.addWidget(self.day_spin)
        hbox.addWidget(self.btn)

        vbox.addLayout(hbox)
        vbox.addWidget(self.label1)
        vbox.addWidget(self.label2)
        vbox.addWidget(self.label3)
        vbox.addWidget(self.label4)

        
        #print(self.get_date_string())
        #print(self.birc.daysToNextBirthday())

        self.setLayout(vbox)

        # 显示窗口
        self.show()

    def show_text(self):
        self.birc=BirthdayCalculator(self.get_date_string())
        self.label1.setText('你的生日是:'+self.get_date_string())
        self.label2.setText('今天的日期是:'+self.birc.today())
        self.label3.setText('今天到下次生日还有'+str(self.birc.daysToNextBirthday())+'天')
        self.label4.setText('按任意键进入下一环节')

    def get_date_string(self):
        # 获取QSpinBox控件的值并返回日期字符串
        year = str(self.year_spin.value())
        month = str(self.month_spin.value()).zfill(2)
        day = str(self.day_spin.value()).zfill(2)
        return f'{year}-{month}-{day}'
    #def link(self, p) :
    #    self.wlink = p

class page_3(QWidget):
    def __init__(self,birth,par):
        super().__init__()
        self.birth=birth
        self.par=par
        # if hasattr(self, 'btn2'):
        #     self.btn2.setParent(None)
        #     del self.btn2
        self.ise=0
        self.initUI()
    def initUI(self):
        self.birc=BirthdayCalculator(self.birth)
        self.s1=self.birc.nextBirthday()
        self.label1 = QLabel('下次生日日期为'+self.birc.nextBirthday(),self)
        self.label1.setAlignment(Qt.AlignLeft)
        self.s2=str(self.birc.daysToNextBirthday())
        self.label2 = QLabel('下次生日距今天的天数'+str(self.birc.daysToNextBirthday()),self)
        self.label2.setAlignment(Qt.AlignLeft)
        self.label3 = QLabel('请输入您希望提前多少天做聚会计划',self)
        self.label3.setAlignment(Qt.AlignLeft)
        hbox = QHBoxLayout()
        self.le = QLineEdit(self)
        self.btn = QPushButton('确认', self)
        self.btn.clicked.connect(self.show_text)
        hbox.addWidget(self.label3)
        hbox.addWidget(self.le)
        hbox.addWidget(self.btn)

        # 计划时间
        self.label4 = QLabel(self)
        self.label4.setAlignment(Qt.AlignLeft)
        # 是否为工作日
        self.label5 = QLabel(self)
        self.label5.setAlignment(Qt.AlignLeft)

        vbox = QVBoxLayout()
        vbox.addWidget(self.label1)
        vbox.addWidget(self.label2)
        #vbox.addWidget(self.label3)
        vbox.addLayout(hbox)
        vbox.addWidget(self.label4)
        self.hbox2 = QHBoxLayout()
        self.hbox2.addWidget(self.label5)
        vbox.addLayout(self.hbox2)
        self.setLayout(vbox)
        # self.s3=self.pp[0]
        # self.s4=self.pp[2]
        self.show()


        self.paa=(1,2,3,4)
        # 这有问题传不出去


        #self.le.returnPressed.connect(self.showpp) 

    # def showpp(self):
    #     self.input_text = self.le.text()
    #     self.paa=self.birc.nDaysBeforeNextBirthday(int(self.input_text))

    def show_text(self):
        pp=self.birc.nDaysBeforeNextBirthday(int(self.le.text()))
        self.par.page4.label3.setText('原本计划日期:'+pp[0])
        self.par.page4.label4.setText('更正至周末的计划的日期:'+pp[2])
        self.par.tx5_1.setText("计划日期是:"+pp[2]+",属于周末")
        #self.mSig.emit(self.pp)
        #self.s3=pp[0]
        #self.s4=pp[2]
        days=['一','二','三','四','五','六','日']
        self.label4.setText('你的计划日期是:'+pp[0]+',它是周'+days[pp[3]])
        if(pp[1]==False):
            self.label5.setText('不为休息日，建议您更改为最近的周六，日期为'+pp[2])
        else:
            self.label5.setText('它属于一个周末')

        if self.ise==0:
            self.btn2 = QPushButton('确认', self)
            self.btn2.clicked.connect(self.tran)
            self.hbox2.addWidget(self.btn2)
            self.ise=1

    # def spp(self):
    #     pp=self.birc.nDaysBeforeNextBirthday(int(self.le.text()))
    #     return pp

    # def gd1(self):
    #     pp=self.spp()
    #     return pp[0]

    # def gd2(self):
    #     pp=self.spp()
    #     return pp[2]

    def tran(self):
        self.wlink.stacked_widget.setCurrentIndex(3)
        self.wlink.now = 3
    
    def link(self, p) :
        self.wlink = p


class page_4(QWidget):
    def __init__(self,info):
        super().__init__()
        self.info=info
        self.initUI()
       

    def initUI(self):

        self.label1 = QLabel("下次生日日期:"+self.info[0],self)
        self.label1.setAlignment(Qt.AlignLeft)
        self.label2 = QLabel("下次生日距离今天的天数:"+self.info[1],self)
        self.label2.setAlignment(Qt.AlignLeft)
        self.label3 = QLabel("原本计划日期:")
        self.label3.setAlignment(Qt.AlignLeft)
        self.label4 = QLabel("更正至周末的计划的日期:")
        self.label4.setAlignment(Qt.AlignLeft)

        hbox = QHBoxLayout()
        self.label5 = QLabel("是否需要重新选择:",self)
        self.btn1 = QPushButton('是')
        self.btn1.clicked.connect(self.tran1)
        self.btn2 = QPushButton('否')
        self.btn2.clicked.connect(self.tran2)
        hbox.addWidget(self.label5)
        hbox.addWidget(self.btn1)
        hbox.addWidget(self.btn2)


        vbox = QVBoxLayout()
        vbox.addWidget(self.label1)
        vbox.addWidget(self.label2)
        vbox.addWidget(self.label3)
        vbox.addWidget(self.label4)
        vbox.addLayout(hbox)

        self.setLayout(vbox)

        # 显示窗口
        self.show()

    def tran1(self):
        self.wlink.stacked_widget.setCurrentIndex(2)
        self.wlink.now = 2

    def tran2(self):
        self.wlink.stacked_widget.setCurrentIndex(4)
        self.wlink.now = 4
    
    def link(self, p) :
        self.wlink = p


class WindowClass(QWidget):
    def __init__(self,parent=None):
        super(WindowClass, self).__init__(parent)
        self.Window_Title="生日聚会计划便签"
        self.setWindowTitle(self.Window_Title)
        self.resize(320,200)
        # 页面号 0-4
        self.now=0
        self.stacked_widget = QStackedWidget()

        # 页面1
        self.page1=QWidget()

        # self.bkg=QLabel()
        pix_img=QPixmap("bkg.png")
        pix_img=pix_img.scaled(320, 200)

        bkimg = QLabel(self.page1)
        bkimg.setPixmap(pix_img)
        bkimg.resize(self.width(), self.height())

        #page1.layout=QVBoxLayout()
        stxt=QLabel()
        stxt.setText("请按任意键继续")
        stxt.setAlignment(Qt.AlignCenter)
        font = QFont('Arial', 30)
        stxt.setFont(font)
        layout1=QVBoxLayout()
        layout1.addWidget(stxt)
        layout1.addStretch()
        self.page1.setLayout(layout1)


        # 页面2
        self.page2 = page_2()
        #page2.link(self)
        self.bir=self.page2.get_date_string()
        # 页面3
        #self.pp=()
        self.page3 = page_3(self.bir,self)
        self.page3.link(self)
        #print('pp',self.pp)
        # 页面4
        self.page4 = page_4((self.page3.s1,self.page3.s2))
        self.page4.link(self)

        # 页面5
        self.page5 = QWidget()
        self.tx5_1=QLabel()
        self.tx5_1.setText("计划日期是:"+''+",属于周末")
        self.tx5_1.setAlignment(Qt.AlignLeft)
        tx5_2=QLabel()
        tx5_2.setText("请按任意键退出---")
        tx5_2.setAlignment(Qt.AlignLeft)

        layout5=QVBoxLayout()
        layout5.addWidget(self.tx5_1)
        layout5.addWidget(tx5_2)
        self.page5.setLayout(layout5)


        self.stacked_widget.addWidget(self.page1)
        self.stacked_widget.addWidget(self.page2)
        self.stacked_widget.addWidget(self.page3)
        self.stacked_widget.addWidget(self.page4)
        self.stacked_widget.addWidget(self.page5)

        layout=QVBoxLayout()
        layout.addWidget(self.stacked_widget)
        self.setLayout(layout)

    def keyPressEvent(self, event):
        if event.type()==QEvent.KeyPress and self.now==0:
            self.stacked_widget.setCurrentIndex(1)
            self.now=1
            return 
            
        if event.type()==QEvent.KeyPress and self.now==1:
            self.stacked_widget.setCurrentIndex(2)
            self.now=2
            return

        if event.type()==QEvent.KeyPress and self.now==4:
            QApplication.quit()
            return


if __name__=="__main__":
    app=QApplication(sys.argv)
    win=WindowClass()
    win.show()
    sys.exit(app.exec_())