from datetime import date, datetime, timedelta

class BirthdayCalculator :
    def __init__(self, birthday_str) -> None:
        self.birthday = datetime.strptime(birthday_str, r'%Y-%m-%d').date()

    def date2str(self, d : date) -> str :
        return d.strftime(r'%Y-%m-%d')

    def _today(self) -> date :
        return date.today()

    def today(self) -> str :
        return self.date2str(self._today())

    def _nextBirthday(self) -> date :
        def isValidDate(y, m, d) :
            try:
                date(y, m, d)
            except:
                return False
            else:
                return True
        
        (y,m,d) = (self.birthday.year, self.birthday.month, self.birthday.day)
        now = date.today()
        nxty = now.year
        while not (isValidDate(nxty,m,d) and date(nxty,m,d) >= now) :
            nxty += 1
        
        return date(nxty,m,d)
    
    def nextBirthday(self) -> str :
        return self.date2str(self._nextBirthday())

    def daysToNextBirthday(self) -> int :
        return (self._nextBirthday() - self._today()).days
    
    def nDaysBeforeNextBirthday(self, n) -> tuple :
        d = self._nextBirthday() - timedelta(days=n)
        d2 = d + timedelta(days=[-1,-2,3,2,1,0,0][d.weekday()])
        return self.date2str(d), d.weekday() in [5,6], self.date2str(d2), d.weekday()

C = BirthdayCalculator('2002-03-01')
print(C.nextBirthday())
print(C.today())
print(C.daysToNextBirthday())
print(C.nDaysBeforeNextBirthday(3))
D = C.nDaysBeforeNextBirthday(4)

print(D[0],D[1],D[2])